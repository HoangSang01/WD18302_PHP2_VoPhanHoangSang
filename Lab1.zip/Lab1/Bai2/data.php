<?
$course = [
    's1' => 'Toán',
    's2' => 'Lý',
    's3' => 'Ngoại Ngữ'
];
?>
